const e=""+new URL("uni-cfd8fa94.png",import.meta.url).href;export{e as _};
